import React, { useEffect, useState } from "react";
import { DataProvider } from "../Store/store";
import axios from "axios";
const Action = ({ children }) => {
      const [data, setData] = useState([]);
  const [user, setUser] = useState({
    name: "",
    email: "",
    age: "",
    image: "",
    address: "",
  });
  let clearForm = { name: "", age: "", email: "", address: "", image: "" };
  // change Form type
  const [checkForm, setCheckForm] = useState("Add");
  // modal State
  const [show, setShow] = useState(false);

  // getUSer ID

  const [userId, setUserId] = useState("");
  // Model Function
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const getData = async () => {
    let data = await axios.get(
      "https://689828dcddf05523e55e3d33.mockapi.io/user/users"
    );
    setData(data.data);
  };
  const AddUser = async () => {
    await axios.post(
      `https://689828dcddf05523e55e3d33.mockapi.io/user/users`,
      user
    );
    getData();
  };

  const deleteUser = async (id) => {
    let checkDel = confirm("You want to delete..");
    if (checkDel) {
      await axios.delete(
        `https://689828dcddf05523e55e3d33.mockapi.io/user/users/${id}`
      );
      getData();
    }
  };

  const getSingleUser = async (id) => {
    let singleUser = await axios.get(
      `https://689828dcddf05523e55e3d33.mockapi.io/user/users/${id}`
    );
    setUser(singleUser.data);
  };

  const EditUser = async () => {
    await axios.put(
      `https://689828dcddf05523e55e3d33.mockapi.io/user/users/${userId}`,
      user
    );
    getData();
  };

  const readUser = async (id)=>{
      let singleUser = await axios.get(
        `https://689828dcddf05523e55e3d33.mockapi.io/user/users/${id}`
      );
      setUser(singleUser.data);
  }
  return <DataProvider value={ {data,
        getData,
        handleClose,
        handleShow,
        show,
        user,
        setUser,
        AddUser,
        deleteUser,
        checkForm,
        setCheckForm,
        getSingleUser,
        EditUser,
        setUserId,
        userId,
        clearForm,
        readUser}}>
    {children}
    </DataProvider>;
};

export default Action;
