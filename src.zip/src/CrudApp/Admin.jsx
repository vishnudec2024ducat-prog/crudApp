import React, { useContext, useEffect, useState } from 'react'
import { DataProvider } from '../Store/store';
import ModalForm from './ModalForm';
import { CiEdit } from "react-icons/ci";
import { MdDelete } from "react-icons/md";
import { CiRead } from "react-icons/ci";
const Admin = () => {
      const {
        data,
        getData,
        deleteUser,
        handleShow,
        setCheckForm,
        getSingleUser,
        setUserId,
        readUser,
      } = useContext(DataProvider);


      const handleEdit = (id)=>{
        setUserId(id)
        setCheckForm("Edit");
        getSingleUser(id)
       handleShow()
      }

      const handleRead = (id)=>{
        // setUserId(id)
        setCheckForm("Read")
        readUser(id);
        handleShow()
      }
      useEffect(()=>{
          getData()
      },[])
  return (
    <>
      <ModalForm />
      <table className="table table-bordered text-center align-middle">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Age</th>
            <th scope="col">Photo</th>
            <th scope="col">Address</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((elm,ind) => (
            <tr key={elm.id}>
              <th scope="row">{ind + 1}</th>
              <td>{elm.name}</td>
              <td>{elm.email}</td>
              <td>{elm.age}</td>
              <td>
                <img
                  src={elm.image}
                  alt=""
                  className="w-50 img-fluid"
                  style={{ height: "100px" }}
                />
              </td>
              <td>{elm.address}</td>
              <td>
                <div
                  className="btn-group"
                  role="group"
                  aria-label="Basic example"
                >
                  <button type="button" className="btn btn-success " onClick={()=>handleEdit(elm.id)}>
                    <CiEdit/>
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger mx-2"
                    onClick={()=>deleteUser(elm.id)}
                  >
                    <MdDelete />
                  </button>
                  <button type="button" className="btn btn-warning" onClick={()=>handleRead(elm.id)}>
                    <CiRead />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default Admin