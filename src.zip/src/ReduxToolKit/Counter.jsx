import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { decreement, increement, reset } from './CounterSlice';

const Counter = () => {
  const dispatch =  useDispatch()
  let {name,method,count} =   useSelector((state)=>state.counterApp)
  return (
    <div className="container">
      <div className="row">
        <div className="col-6 mx-auto mt-5 border text-center">
          <h1>Counter App</h1>
          <h1>Name: {name}</h1>
          <h1>Method: {method}</h1>
          <h1>Count: {count}</h1>
          <div>
            <button
              className="btn btn-success"
              onClick={() =>
                dispatch(increement({ name: "Saurav", method: "Increment" }))
              }
            >
              Inc
            </button>
            <button
              className="btn btn-danger mx-5"
              onClick={() =>
                dispatch(decreement({ name: "Reena", method: "Dcrement" }))
              }
            >
              Dec
            </button>
            <button
              className="btn btn-danger mx-5"
              onClick={() =>
                dispatch(reset({ name: "Raam", method: "Reset" }))
              }
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Counter