import {configureStore} from "@reduxjs/toolkit"
import counterSlice from "./CounterSlice.js"
const store = configureStore({   
    reducer:{
        counterApp:counterSlice
       
    }
})

export default store