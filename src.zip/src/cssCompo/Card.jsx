import React from 'react'
// import "./Card.css"
import obj from "./card.module.css"
const Card = () => {
  return (
    <div className={`container ${obj.bgRed} `}>Card</div>
  )
}

export default Card